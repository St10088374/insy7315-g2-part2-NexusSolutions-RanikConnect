import { Router } from 'express';
import { asyncHandler } from '../utils/http.js';
import { register,login,refresh,logout,me,verifyEmail,forgotPassword,resetPassword } from '../controllers/auth.controller.js';
import { requireAuth } from '../middleware/auth.js';
const r=Router();
r.post('/register',asyncHandler(register));r.post('/login',asyncHandler(login));r.post('/refresh',asyncHandler(refresh));r.post('/logout',asyncHandler(logout));r.get('/me',requireAuth,asyncHandler(me));r.get('/verify-email',asyncHandler(verifyEmail));r.post('/forgot-password',asyncHandler(forgotPassword));r.post('/reset-password',asyncHandler(resetPassword));export default r;
