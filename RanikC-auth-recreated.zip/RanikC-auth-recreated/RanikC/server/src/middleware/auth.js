import { verifyAccess } from '../utils/jwt.js';
import { User } from '../models/user.model.js';
import { AppError,asyncHandler } from '../utils/http.js';
export const requireAuth=asyncHandler(async(req,res,next)=>{const h=req.get('authorization');if(!h?.startsWith('Bearer '))throw new AppError(401,'Authentication required','UNAUTHENTICATED');let p;try{p=verifyAccess(h.slice(7));}catch{throw new AppError(401,'Invalid or expired access token','INVALID_TOKEN');}const user=await User.findById(p.sub);if(!user)throw new AppError(401,'Authentication required','UNAUTHENTICATED');req.user=user;next();});
export const requireRole=(...roles)=> (req,res,next)=>{if(!req.user||!roles.includes(req.user.role))return next(new AppError(403,'Forbidden','FORBIDDEN'));next();};
