import 'dotenv/config';
import { z } from 'zod';
const schema=z.object({NODE_ENV:z.enum(['development','test','production']).default('development'),PORT:z.coerce.number().default(5000),CLIENT_URL:z.string().url(),MONGODB_URI:z.string().min(1),JWT_ACCESS_SECRET:z.string().min(32),JWT_REFRESH_SECRET:z.string().min(32),ACCESS_TOKEN_TTL:z.string().default('15m'),REFRESH_TOKEN_TTL_DAYS:z.coerce.number().int().positive().default(7),COOKIE_NAME:z.string().default('ranikc_refresh'),SMTP_HOST:z.string().optional(),SMTP_PORT:z.coerce.number().default(587),SMTP_USER:z.string().optional(),SMTP_PASS:z.string().optional(),MAIL_FROM:z.string().default('RanikC <no-reply@example.com>')});
export const env=schema.parse(process.env);
