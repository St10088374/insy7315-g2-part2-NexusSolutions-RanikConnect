import nodemailer from 'nodemailer';
import { env } from '../config/env.js';
let transporter=null;
if(env.SMTP_HOST&&env.SMTP_USER&&env.SMTP_PASS) transporter=nodemailer.createTransport({host:env.SMTP_HOST,port:env.SMTP_PORT,secure:env.SMTP_PORT===465,auth:{user:env.SMTP_USER,pass:env.SMTP_PASS}});
export async function sendMail({to,subject,text,html}){if(!transporter){if(env.NODE_ENV==='production') throw new Error('SMTP is not configured'); console.log(`\n[MAIL DEV]\nTo: ${to}\nSubject: ${subject}\n${text}\n`);return;} await transporter.sendMail({from:env.MAIL_FROM,to,subject,text,html});}
