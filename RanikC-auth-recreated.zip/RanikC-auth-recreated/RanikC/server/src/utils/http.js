export class AppError extends Error{constructor(status,message,code='ERROR'){super(message);this.status=status;this.code=code;}}
export const asyncHandler=fn=>(req,res,next)=>Promise.resolve(fn(req,res,next)).catch(next);
export function sanitizeUser(u){return {_id:u._id,name:u.name,email:u.email,role:u.role,isEmailVerified:u.isEmailVerified,createdAt:u.createdAt};}
