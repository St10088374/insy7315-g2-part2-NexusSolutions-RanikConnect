import jwt from 'jsonwebtoken';
import { env } from '../config/env.js';
export const signAccessToken=(user)=>jwt.sign({sub:user._id.toString(),role:user.role,type:'access'},env.JWT_ACCESS_SECRET,{expiresIn:env.ACCESS_TOKEN_TTL});
export const signRefreshToken=(user,sessionId)=>jwt.sign({sub:user._id.toString(),sid:sessionId.toString(),ver:user.tokenVersion,type:'refresh'},env.JWT_REFRESH_SECRET,{expiresIn:`${env.REFRESH_TOKEN_TTL_DAYS}d`});
export const verifyAccess=t=>jwt.verify(t,env.JWT_ACCESS_SECRET);
export const verifyRefresh=t=>jwt.verify(t,env.JWT_REFRESH_SECRET);
