import { env } from '../config/env.js';
export function setRefreshCookie(res,token){res.cookie(env.COOKIE_NAME,token,{httpOnly:true,secure:env.NODE_ENV==='production',sameSite:'strict',path:'/api/auth',maxAge:env.REFRESH_TOKEN_TTL_DAYS*86400000});}
export function clearRefreshCookie(res){res.clearCookie(env.COOKIE_NAME,{httpOnly:true,secure:env.NODE_ENV==='production',sameSite:'strict',path:'/api/auth'});}
