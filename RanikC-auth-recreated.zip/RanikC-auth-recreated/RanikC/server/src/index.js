import express from 'express';import cors from 'cors';import helmet from 'helmet';import cookieParser from 'cookie-parser';import rateLimit from 'express-rate-limit';
import { env } from './config/env.js';import { connectDB } from './config/db.js';import authRoutes from './routes/auth.routes.js';import { notFound,errorHandler } from './middleware/error.js';
const app=express();app.disable('x-powered-by');app.set('trust proxy',1);app.use(helmet());app.use(cors({origin:env.CLIENT_URL,credentials:true}));app.use(express.json({limit:'50kb'}));app.use(cookieParser());
const authLimiter=rateLimit({windowMs:15*60*1000,max:50,standardHeaders:true,legacyHeaders:false});app.use('/api/auth',authLimiter);app.get('/api/health',(req,res)=>res.json({success:true,status:'ok'}));app.use('/api/auth',authRoutes);app.use(notFound);app.use(errorHandler);
connectDB().then(()=>app.listen(env.PORT,()=>console.log(`RanikC API listening on ${env.PORT}`))).catch(err=>{console.error(err);process.exit(1)});
