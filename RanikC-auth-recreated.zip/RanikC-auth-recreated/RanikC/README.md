# RanikC — Production-oriented MERN Authentication Foundation

This is a standalone recreation of the authentication architecture demonstrated in the referenced MERN authentication tutorial, adapted into an empty RanikC project. It deliberately improves the common tutorial pattern with refresh-session rotation, hashed server-side session records, HTTP-only cookies, validation, rate limiting, security headers, generic password-reset responses, and session invalidation on password reset.

## Stack
- React + Vite frontend
- Express API
- MongoDB + Mongoose
- JWT access tokens
- Rotating HTTP-only refresh sessions
- bcrypt password hashing
- Zod validation
- Nodemailer email delivery
- Helmet, CORS and rate limiting

## Authentication flows
1. Register → password hash → verification email token → refresh session + access token.
2. Login → credential validation → refresh session + short-lived access token.
3. Refresh → validate refresh JWT and hashed session → rotate session → issue new access token.
4. Logout → delete refresh session + clear cookie.
5. Verify email → one-time expiring token.
6. Forgot password → generic response to prevent account enumeration.
7. Reset password → expiring token → password hash update → invalidate all sessions.
8. Protected `/api/auth/me` route.

## Run
Requirements: Node.js 20+, MongoDB.

```bash
cp server/.env.example server/.env
# Fill MONGODB_URI and both JWT secrets.
npm install
npm run install:all
npm run dev
```

For production, configure real SMTP, HTTPS, a strong secrets manager, a reverse proxy, monitoring/logging, and a distributed rate-limit/session strategy such as Redis if running multiple API instances.
