# RanikConnect Driver Mobile App

## Overview

The RanikConnect Driver Mobile App is an Android application for drivers to log in, view assigned trips, update trip milestones, and submit proof-of-delivery photos.

## Main Features

- Driver login and registration
- Secure session handling
- Driver dashboard with assigned trips
- Trip details screen
- Delivery milestone updates:
  - Departed
  - In transit
  - Arrived
- Milestone history
- Proof-of-delivery camera capture

## Technology Used

- Kotlin
- Android Studio
- Android `FileProvider`
- Android camera permission APIs
- REST API communication

## AI Use Declaration

OpenAI Codex was used to help me understand the architecture and Kotlin framework of the RanikConnect Driver Mobile Application. I also used it as a debugging aid for build, Android Manifest, Gradle, camera-permission, and resource-linking issues. I used it as a guide to help add changes. Codex was used to support my learning and troubleshooting in bugs that came up.

The following references were also consulted when making changes. This was done to understand the changes being made.

## References

1. OpenAI (n.d.) *Codex*. Available at: https://developers.openai.com/learn/codex (Accessed: 4 October 2026).

2. Android Developers (n.d.) *State and Jetpack Compose*. Available at: https://developer.android.com/develop/ui/compose/state (Accessed: 4 October 2026).

3. Android Developers (n.d.) *Request runtime permissions*. Available at: https://developer.android.com/training/permissions/requesting (Accessed: 4 October 2026).

4. Android Developers (n.d.) *ActivityResultContracts.TakePicture*. Available at: https://developer.android.com/reference/androidx/activity/result/contract/ActivityResultContracts.TakePicture (Accessed: 4 October 2026).

5. Android Developers (n.d.) *FileProvider*. Available at: https://developer.android.com/reference/androidx/core/content/FileProvider (Accessed: 4 October 2026).

6. Android Developers (n.d.) *Setting up file sharing*. Available at: https://developer.android.com/training/secure-file-sharing/setup-sharing (Accessed: 4 October 2026).