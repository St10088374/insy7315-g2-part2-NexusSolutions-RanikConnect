package com.example.ranikconnectdrivermobileapp

import android.Manifest
import android.content.pm.PackageManager
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.content.ContextCompat
import com.example.ranikconnectdrivermobileapp.data.CameraCaptureManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import com.example.ranikconnectdrivermobileapp.ui.AuthController
import com.example.ranikconnectdrivermobileapp.ui.AuthScreen
import com.example.ranikconnectdrivermobileapp.ui.DriverDashboardScreen
import com.example.ranikconnectdrivermobileapp.ui.LoginScreen
import com.example.ranikconnectdrivermobileapp.ui.RegisterScreen
import com.example.ranikconnectdrivermobileapp.ui.TripDetailsScreen
import com.example.ranikconnectdrivermobileapp.ui.theme.RanikConnectDriverMobileAppTheme
import com.example.ranikconnectdrivermobileapp.ui.ProofOfDeliveryScreen

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            RanikConnectDriverMobileAppTheme {
                val controller = remember { AuthController(applicationContext) }
                val cameraCaptureManager = remember { CameraCaptureManager(applicationContext) }
                var pendingPhotoUri by remember { mutableStateOf<Uri?>(null) }
                val photoCaptureLauncher = rememberLauncherForActivityResult(
                    ActivityResultContracts.TakePicture()
                ) { photoSaved ->
                    if (photoSaved) controller.setProofPhoto(pendingPhotoUri)
                    pendingPhotoUri = null
                }
                val cameraPermissionLauncher = rememberLauncherForActivityResult(
                    ActivityResultContracts.RequestPermission()
                ) { granted ->
                    if (granted) pendingPhotoUri?.let(photoCaptureLauncher::launch)
                }
                val startPhotoCapture = {
                    val photoUri = cameraCaptureManager.createPhotoUri()
                    pendingPhotoUri = photoUri
                    val permissionGranted = ContextCompat.checkSelfPermission(
                        applicationContext, Manifest.permission.CAMERA
                    ) == PackageManager.PERMISSION_GRANTED
                    if (permissionGranted) {
                        photoCaptureLauncher.launch(photoUri)
                    } else {
                        cameraPermissionLauncher.launch(Manifest.permission.CAMERA)
                    }
                }
                DisposableEffect(Unit) {
                    onDispose { controller.close() }
                }
                LaunchedEffect(Unit) { controller.initialize() }

                if (controller.loading && controller.user == null) {
                    Box(
                        modifier = Modifier.fillMaxSize()
                            .background(androidx.compose.material3.MaterialTheme.colorScheme.background),
                        contentAlignment = Alignment.Center
                    ) {
                        CircularProgressIndicator()
                    }
                } else {
                    when (controller.screen) {
                        AuthScreen.Login -> LoginScreen(controller)
                        AuthScreen.Register -> RegisterScreen(controller)
                        AuthScreen.Dashboard -> DriverDashboardScreen(controller)
                        AuthScreen.TripDetails -> {
                            val trip = controller.selectedTrip
                            if (trip == null) {
                                DriverDashboardScreen(controller)
                            } else {
                                TripDetailsScreen(
                                    trip = trip,
                                    milestones = controller.milestones,
                                    submittingMilestone = controller.submittingMilestone,
                                    message = controller.message,
                                    onBack = controller::backToDashboard,
                                    onRecordMilestone = controller::recordMilestone,
                                    onOpenProofOfDelivery = controller::openProofOfDelivery
                                )
                            }
                        }

                        AuthScreen.ProofOfDelivery -> {
                            ProofOfDeliveryScreen(
                                photoUri = controller.proofPhotoUri,
                                uploading = controller.uploadingProof,
                                message = controller.message,
                                onBack = controller::backToTripDetails,
                                onTakePhoto = startPhotoCapture,
                                onRetakePhoto = startPhotoCapture,
                                onSubmit = controller::submitProofOfDelivery)
                        }
                    }
                }
            }
        }
    }
}
