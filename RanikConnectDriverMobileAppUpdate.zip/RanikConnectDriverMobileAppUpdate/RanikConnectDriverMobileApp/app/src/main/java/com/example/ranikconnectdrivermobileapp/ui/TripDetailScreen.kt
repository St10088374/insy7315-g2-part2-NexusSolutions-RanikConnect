package com.example.ranikconnectdrivermobileapp.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.ranikconnectdrivermobileapp.data.DriverTrip
import com.example.ranikconnectdrivermobileapp.data.DriverTripMilestone


@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TripDetailsScreen(
    trip: DriverTrip,
    milestones: List<DriverTripMilestone>,
    submittingMilestone: Boolean,
    message: String?,
    onBack: () -> Unit,
    onRecordMilestone: (String) -> Unit,
    onOpenProofOfDelivery: () -> Unit
) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(trip.bookingReference.ifBlank { "Trip details" }) },
                navigationIcon = { OutlinedButton(onClick = onBack) { Text("Back") } })
        }) { padding ->
        Column(
            modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            TripInformationCard(trip)
            message?.let {
                Text(
                    text = it, color = if (it.contains("successfully", ignoreCase = true)) {
                        MaterialTheme.colorScheme.primary
                    } else {
                        MaterialTheme.colorScheme.error
                    }
                )
            }
            Text(
                "Update trip progress",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    enabled = !submittingMilestone,
                    onClick = { onRecordMilestone("DEPARTED") }) { Text("Departed") }
                Button(
                    enabled = !submittingMilestone,
                    onClick = { onRecordMilestone("IN_TRANSIT") }) { Text("In transit") }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    enabled = !submittingMilestone,
                    onClick = { onRecordMilestone("ARRIVED") }) { Text("Arrived") }
                OutlinedButton(onClick = onOpenProofOfDelivery) { Text("Proof of delivery") }
            }

            Text(
                "Milestone history",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
            if (milestones.isEmpty()) {
                Text("No progress updates have been recorded yet.")
            } else {
                milestones.forEach { milestone ->
                    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
                        Column(Modifier.fillMaxWidth().padding(12.dp)) {
                            Text(
                                milestone.eventType.replace('_', ' '),
                                fontWeight = FontWeight.SemiBold
                            )
                            Text(milestone.timestamp, style = MaterialTheme.typography.bodySmall)
                            if (milestone.note.isNotBlank()) Text(milestone.note)
                            if (milestone.location.isNotBlank()) Text(
                                milestone.location, style = MaterialTheme.typography.bodySmall
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun TripInformationCard(trip: DriverTrip) {
    Card {
        Column(
            Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Text(
                "${trip.origin} → ${trip.destination}",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
            DetailRow("Status", trip.currentStatus.ifBlank { trip.status })
            DetailRow("Scheduled", trip.scheduledDate.ifBlank { "Not scheduled" })
            DetailRow(
                "Vehicle",
                trip.vehicleRegistration.ifBlank { trip.vehicleName.ifBlank { "Not assigned" } })
            if (trip.cargo.isNotBlank()) DetailRow("Cargo", trip.cargo)
            trip.eta?.let { DetailRow("Estimated arrival", it) }
        }
    }
}

@Composable
private fun DetailRow(label: String, value: String) {
    Row(Modifier.fillMaxWidth()) {
        Text("$label:", modifier = Modifier.width(130.dp), fontWeight = FontWeight.SemiBold)
        Text(value, modifier = Modifier.weight(1f))
    }
}
