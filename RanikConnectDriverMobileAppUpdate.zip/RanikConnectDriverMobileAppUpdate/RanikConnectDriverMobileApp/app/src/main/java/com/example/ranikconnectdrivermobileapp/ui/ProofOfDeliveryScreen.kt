package com.example.ranikconnectdrivermobileapp.ui

import android.graphics.BitmapFactory
import android.net.Uri
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProofOfDeliveryScreen(
    photoUri: Uri?,
    uploading: Boolean,
    message: String?,
    onBack: () -> Unit,
    onTakePhoto: () -> Unit,
    onRetakePhoto: () -> Unit,
    onSubmit: () -> Unit
) {
    val context = LocalContext.current
    val preview = remember(photoUri) {
        photoUri?.let { uri ->
            context.contentResolver.openInputStream(uri)?.use(BitmapFactory::decodeStream)
                ?.asImageBitmap()
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Proof of delivery") },
                navigationIcon = { OutlinedButton(onClick = onBack) { Text("Back") } })
        }) { padding ->
        Column(
            modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Text("Take a clear photo of the delivered shipment or signed document.")
            message?.let {
                Text(
                    text = it,
                    color = if (it.contains("successfully", ignoreCase = true)) {
                        MaterialTheme.colorScheme.primary
                    } else {
                        MaterialTheme.colorScheme.error
                    }
                )
            }
            if (preview == null) {
                Text("No photo selected yet.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                Button(onClick = onTakePhoto) { Text("Take photo") }
            } else {
                Image(
                    bitmap = preview,
                    contentDescription = "Proof of delivery photo preview",
                    modifier = Modifier.fillMaxWidth().weight(1f),
                    contentScale = ContentScale.Fit
                )
                OutlinedButton(
                    onClick = onRetakePhoto, enabled = !uploading
                ) { Text("Retake photo") }
                Button(onClick = onSubmit, enabled = !uploading) {
                    Text(if (uploading) "Uploading…" else "Submit proof")
                }
            }
        }
    }
}
