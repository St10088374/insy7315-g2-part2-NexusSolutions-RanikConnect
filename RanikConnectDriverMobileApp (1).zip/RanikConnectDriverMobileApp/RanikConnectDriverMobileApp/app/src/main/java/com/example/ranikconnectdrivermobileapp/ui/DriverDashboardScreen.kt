package com.example.ranikconnectdrivermobileapp.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.LocalShipping
import androidx.compose.material.icons.filled.Logout
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Route
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import java.time.OffsetDateTime
import java.time.format.DateTimeFormatter

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DriverDashboardScreen(controller: AuthController) {
    val user = controller.user ?: return

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("Driver Operations", fontWeight = FontWeight.Bold)
                        Text(user.name, style = MaterialTheme.typography.labelMedium)
                    }
                },
                navigationIcon = { Icon(Icons.Default.LocalShipping, contentDescription = null, modifier = Modifier.padding(start = 14.dp, end = 6.dp)) },
                actions = {
                    IconButton(onClick = controller::refreshTrips) { Icon(Icons.Default.Refresh, contentDescription = "Refresh") }
                    IconButton(onClick = controller::logout) { Icon(Icons.Default.Logout, contentDescription = "Sign out") }
                }
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Spacer(Modifier.height(4.dp))
                Surface(shape = RoundedCornerShape(22.dp), color = MaterialTheme.colorScheme.primaryContainer) {
                    Column(Modifier.fillMaxWidth().padding(18.dp)) {
                        Text("Good to have you on the road.", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(4.dp))
                        Text("Your mobile app is connected to the RanikConnect MERN operations platform.")
                    }
                }
            }

            controller.message?.let { msg ->
                item { Text(msg, color = MaterialTheme.colorScheme.error) }
            }

            item {
                Text("Assigned trips", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            }

            if (controller.trips.isEmpty()) {
                item {
                    Card(shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
                        Column(Modifier.fillMaxWidth().padding(18.dp)) {
                            Text("No trips are currently assigned.", fontWeight = FontWeight.SemiBold)
                            Spacer(Modifier.height(4.dp))
                            Text("When staff assigns you a trip in the web dashboard, it will appear here.")
                        }
                    }
                }
            } else {
                items(controller.trips, key = { it.id }) { trip ->
                    TripCard(trip)
                }
            }
            item { Spacer(Modifier.height(20.dp)) }
        }
    }
}

@Composable
private fun TripCard(trip: com.example.ranikconnectdrivermobileapp.data.DriverTrip) {
    Card(shape = RoundedCornerShape(22.dp), elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)) {
        Column(Modifier.fillMaxWidth().padding(18.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Column(Modifier.weight(1f)) {
                    Text(trip.bookingReference.ifBlank { "Assigned Trip" }, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Text("${trip.origin} → ${trip.destination}", style = MaterialTheme.typography.bodyMedium)
                }
                AssistChip(onClick = {}, label = { Text(trip.currentStatus.ifBlank { trip.status }.replace('_', ' ')) })
            }
            Spacer(Modifier.height(14.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(18.dp)) {
                InfoItem(Icons.Default.CalendarMonth, formatDate(trip.scheduledDate), "Scheduled")
                InfoItem(Icons.Default.Route, trip.vehicleRegistration.ifBlank { "Vehicle pending" }, "Vehicle")
            }
            if (trip.cargo.isNotBlank()) {
                Spacer(Modifier.height(8.dp))
                Text("Cargo: ${trip.cargo}", style = MaterialTheme.typography.bodySmall)
            }
            if (trip.delayed) {
                Spacer(Modifier.height(8.dp))
                Text("Delay alert active", color = MaterialTheme.colorScheme.error, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
private fun InfoItem(icon: androidx.compose.ui.graphics.vector.ImageVector, value: String, label: String) {
    Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
        Icon(icon, contentDescription = null, modifier = Modifier.padding(top = 2.dp))
        Column {
            Text(value, fontWeight = FontWeight.SemiBold)
            Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

private fun formatDate(value: String): String {
    if (value.isBlank()) return "Not scheduled"
    return try {
        OffsetDateTime.parse(value).format(DateTimeFormatter.ofPattern("dd MMM, HH:mm"))
    } catch (_: Exception) {
        value.take(16).replace('T', ' ')
    }
}
