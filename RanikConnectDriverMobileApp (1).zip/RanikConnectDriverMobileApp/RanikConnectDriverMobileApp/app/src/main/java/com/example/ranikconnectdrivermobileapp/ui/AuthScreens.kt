package com.example.ranikconnectdrivermobileapp.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.LocalShipping
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp

private val BrandBlue = Color(0xFF135DCE)
private val BrandNavy = Color(0xFF0A2342)

@Composable
private fun AuthShell(
    title: String,
    subtitle: String,
    content: @Composable () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    listOf(Color(0xFFF8FBFF), Color(0xFFEFF5FF), Color(0xFFFFFFFF))
                )
            )
            .imePadding()
    ) {
        Column(
            modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(22.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(Modifier.height(24.dp))
            Surface(
                shape = RoundedCornerShape(22.dp),
                color = BrandNavy.copy(alpha = 0.95f)
            ) {
                Icon(
                    Icons.Default.LocalShipping,
                    contentDescription = null,
                    tint = Color.White,
                    modifier = Modifier.padding(18.dp)
                )
            }
            Spacer(Modifier.height(18.dp))
            Text("RanikConnect", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold, color = BrandNavy)
            Text("Driver Mobile", style = MaterialTheme.typography.titleMedium, color = BrandBlue, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(26.dp))

            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(28.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
            ) {
                Column(modifier = Modifier.fillMaxWidth().padding(24.dp)) {
                    Text(title, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(6.dp))
                    Text(subtitle, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(Modifier.height(22.dp))
                    content()
                }
            }
            Spacer(Modifier.height(26.dp))
        }
    }
}

@Composable
fun LoginScreen(controller: AuthController) {
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var showPassword by remember { mutableStateOf(false) }

    AuthShell(
        title = "Welcome back",
        subtitle = "Sign in to view your assigned trips and delivery operations."
    ) {
        controller.message?.let {
            ErrorBanner(it)
            Spacer(Modifier.height(12.dp))
        }

        OutlinedTextField(
            value = email,
            onValueChange = { email = it },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
            label = { Text("Email address") },
            leadingIcon = { Icon(Icons.Default.Email, null) }
        )
        Spacer(Modifier.height(14.dp))
        OutlinedTextField(
            value = password,
            onValueChange = { password = it },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
            label = { Text("Password") },
            leadingIcon = { Icon(Icons.Default.Lock, null) },
            trailingIcon = {
                IconButton(onClick = { showPassword = !showPassword }) {
                    Icon(if (showPassword) Icons.Default.VisibilityOff else Icons.Default.Visibility, null)
                }
            },
            visualTransformation = if (showPassword) VisualTransformation.None else PasswordVisualTransformation()
        )
        Spacer(Modifier.height(20.dp))
        Button(
            onClick = { controller.login(email, password) },
            modifier = Modifier.fillMaxWidth().height(52.dp),
            enabled = !controller.loading && email.isNotBlank() && password.isNotBlank(),
            shape = RoundedCornerShape(16.dp)
        ) {
            Text(if (controller.loading) "Signing in…" else "Sign in", fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(12.dp))
        Row(horizontalArrangement = Arrangement.Center, modifier = Modifier.fillMaxWidth()) {
            Text("New driver account? ")
            TextButton(onClick = controller::goToRegister) { Text("Create one") }
        }
    }
}

@Composable
fun RegisterScreen(controller: AuthController) {
    var name by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var confirmPassword by remember { mutableStateOf("") }
    var showPassword by remember { mutableStateOf(false) }
    var showConfirmPassword by remember { mutableStateOf(false) }

    val validationError = when {
        name.trim().length < 2 -> "Enter your name (at least 2 characters)."
        !android.util.Patterns.EMAIL_ADDRESS.matcher(email.trim()).matches() -> "Enter a valid email address."
        password.length < 6 -> "Password must be at least 6 characters."
        password != confirmPassword -> "Passwords do not match."
        else -> null
    }

    AuthShell(
        title = "Create Driver Account",
        subtitle = "Sign up to access your driver portal and view assigned trips."
    ) {
        controller.message?.let {
            ErrorBanner(it)
            Spacer(Modifier.height(12.dp))
        }

        DriverField(
            value = name,
            onValueChange = { name = it },
            label = "User name / Full name",
            icon = Icons.Default.Person
        )
        Spacer(Modifier.height(12.dp))

        DriverField(
            value = email,
            onValueChange = { email = it },
            label = "Email address",
            icon = Icons.Default.Email
        )
        Spacer(Modifier.height(12.dp))

        DriverField(
            value = password,
            onValueChange = { password = it },
            label = "Password",
            icon = Icons.Default.Lock,
            passwordField = true,
            showPassword = showPassword,
            onTogglePassword = { showPassword = !showPassword }
        )
        Spacer(Modifier.height(12.dp))

        DriverField(
            value = confirmPassword,
            onValueChange = { confirmPassword = it },
            label = "Confirm password",
            icon = Icons.Default.Lock,
            passwordField = true,
            showPassword = showConfirmPassword,
            onTogglePassword = { showConfirmPassword = !showConfirmPassword }
        )
        Spacer(Modifier.height(16.dp))

        validationError?.let {
            Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
            Spacer(Modifier.height(10.dp))
        }

        Button(
            onClick = { controller.register(name, email, password) },
            modifier = Modifier.fillMaxWidth().height(52.dp),
            enabled = !controller.loading && validationError == null,
            shape = RoundedCornerShape(16.dp)
        ) {
            Text(if (controller.loading) "Creating account…" else "Create Account", fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(12.dp))
        Row(horizontalArrangement = Arrangement.Center, modifier = Modifier.fillMaxWidth()) {
            Text("Already have an account? ")
            TextButton(onClick = controller::goToLogin) { Text("Sign in") }
        }
    }
}

@Composable
private fun DriverField(
    value: String,
    onValueChange: (String) -> Unit,
    label: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    passwordField: Boolean = false,
    showPassword: Boolean = false,
    onTogglePassword: (() -> Unit)? = null
) {
    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        modifier = Modifier.fillMaxWidth(),
        singleLine = true,
        label = { Text(label) },
        leadingIcon = { Icon(icon, contentDescription = null) },
        trailingIcon = if (passwordField && onTogglePassword != null) {
            {
                IconButton(onClick = onTogglePassword) {
                    Icon(if (showPassword) Icons.Default.VisibilityOff else Icons.Default.Visibility, null)
                }
            }
        } else null,
        visualTransformation = if (passwordField && !showPassword) PasswordVisualTransformation() else VisualTransformation.None
    )
}

@Composable
private fun ErrorBanner(message: String) {
    Surface(
        color = MaterialTheme.colorScheme.errorContainer,
        shape = RoundedCornerShape(14.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Text(
            text = message,
            modifier = Modifier.padding(12.dp),
            color = MaterialTheme.colorScheme.onErrorContainer,
            style = MaterialTheme.typography.bodyMedium
        )
    }
}
