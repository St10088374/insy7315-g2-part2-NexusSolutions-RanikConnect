package com.example.ranikconnectdrivermobileapp

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import com.example.ranikconnectdrivermobileapp.ui.AuthController
import com.example.ranikconnectdrivermobileapp.ui.AuthScreen
import com.example.ranikconnectdrivermobileapp.ui.DriverDashboardScreen
import com.example.ranikconnectdrivermobileapp.ui.LoginScreen
import com.example.ranikconnectdrivermobileapp.ui.RegisterScreen
import com.example.ranikconnectdrivermobileapp.ui.theme.RanikConnectDriverMobileAppTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            RanikConnectDriverMobileAppTheme {
                val controller = remember { AuthController(applicationContext) }
                DisposableEffect(Unit) {
                    onDispose { controller.close() }
                }
                LaunchedEffect(Unit) { controller.initialize() }

                if (controller.loading && controller.user == null) {
                    Box(
                        modifier = Modifier.fillMaxSize().background(androidx.compose.material3.MaterialTheme.colorScheme.background),
                        contentAlignment = Alignment.Center
                    ) {
                        CircularProgressIndicator()
                    }
                } else {
                    when (controller.screen) {
                        AuthScreen.Login -> LoginScreen(controller)
                        AuthScreen.Register -> RegisterScreen(controller)
                        AuthScreen.Dashboard -> DriverDashboardScreen(controller)
                    }
                }
            }
        }
    }
}
