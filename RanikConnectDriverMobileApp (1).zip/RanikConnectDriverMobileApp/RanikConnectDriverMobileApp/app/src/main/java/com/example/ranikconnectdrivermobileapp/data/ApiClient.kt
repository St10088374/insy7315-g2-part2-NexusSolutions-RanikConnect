package com.example.ranikconnectdrivermobileapp.data

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.nio.charset.StandardCharsets

object ApiConfig {
    // Android emulator -> host machine. For a physical phone, replace 10.0.2.2
    // with the computer's LAN IP and keep the RanikConnect API on port 5000.
    const val BASE_URL = "http://10.0.2.2:5000/api"
}

class ApiException(val statusCode: Int, override val message: String) : Exception(message)

class ApiClient(context: Context) {
    private val tokenStore = SecureTokenStore(context.applicationContext)

    suspend fun login(email: String, password: String): AuthResult =
        authRequest("/auth/driver-login", JSONObject().apply {
            put("email", email)
            put("password", password)
        })

    suspend fun register(
        name: String,
        email: String,
        password: String
    ): AuthResult = authRequest("/auth/driver-register", JSONObject().apply {
        put("name", name)
        put("email", email)
        put("password", password)
    })

    suspend fun restoreSession(): AuthUser? {
        val token = tokenStore.accessToken() ?: run {
            refreshSession()
            tokenStore.accessToken() ?: return null
        }
        return try {
            me(token)
        } catch (error: ApiException) {
            if (error.statusCode != 401) throw error
            refreshSession()?.let { me(it.accessToken) }
        }
    }

    suspend fun refreshSession(): AuthResult? {
        val refreshToken = tokenStore.refreshToken() ?: return null
        return try {
            val response = post("/auth/driver-refresh", JSONObject().put("refreshToken", refreshToken), null)
            val result = authResult(response)
            tokenStore.save(result.accessToken, result.refreshToken)
            result
        } catch (error: ApiException) {
            tokenStore.clear()
            if (error.statusCode == 401 || error.statusCode == 403) null else throw error
        }
    }

    suspend fun logout() {
        tokenStore.clear()
    }

    suspend fun driverTrips(): List<DriverTrip> {
        val json = authedGet("/driver/trips")
        val array = json.optJSONArray("trips") ?: JSONArray()
        return buildList(array.length()) {
            for (index in 0 until array.length()) add(DriverTrip.fromJson(array.getJSONObject(index)))
        }
    }

    suspend fun recordMilestone(tripId: String, eventType: String, note: String, location: String) {
        val body = JSONObject().apply {
            put("eventType", eventType)
            if (note.isNotBlank()) put("note", note)
            if (location.isNotBlank()) put("location", location)
        }
        authedPost("/driver/trips/$tripId/milestone", body)
    }

    suspend fun reportDelay(tripId: String, reason: String, estimatedArrival: String?) {
        val body = JSONObject().put("reason", reason)
        if (!estimatedArrival.isNullOrBlank()) body.put("estimatedArrival", estimatedArrival)
        authedPost("/driver/trips/$tripId/delay", body)
    }

    suspend fun updateLocation(tripId: String, lat: Double, lng: Double, label: String?) {
        val body = JSONObject().put("lat", lat).put("lng", lng)
        if (!label.isNullOrBlank()) body.put("label", label)
        authedPost("/driver/trips/$tripId/location", body)
    }

    private suspend fun me(token: String): AuthUser {
        val json = request("GET", "/auth/me", null, token)
        return AuthUser.fromJson(json.getJSONObject("user"))
    }

    private suspend fun authRequest(path: String, body: JSONObject): AuthResult {
        return withContext(Dispatchers.IO) {
            val response = requestBlocking("POST", path, body, null)
            val result = authResult(response)
            tokenStore.save(result.accessToken, result.refreshToken)
            result
        }
    }

    private suspend fun authedGet(path: String): JSONObject {
        return withAuthenticatedRetry { token -> request("GET", path, null, token) }
    }

    private suspend fun authedPost(path: String, body: JSONObject): JSONObject {
        return withAuthenticatedRetry { token -> request("POST", path, body, token) }
    }

    private suspend fun <T> withAuthenticatedRetry(call: suspend (String) -> T): T {
        val access = tokenStore.accessToken() ?: throw ApiException(401, "Please sign in again")
        return try {
            call(access)
        } catch (error: ApiException) {
            if (error.statusCode != 401) throw error
            val refreshed = refreshSession() ?: throw ApiException(401, "Your session has expired. Please sign in again.")
            call(refreshed.accessToken)
        }
    }

    private suspend fun request(
        method: String,
        path: String,
        body: JSONObject?,
        bearer: String?
    ): JSONObject = withContext(Dispatchers.IO) {
        requestBlocking(method, path, body, bearer)
    }

    private suspend fun post(path: String, body: JSONObject, bearer: String?): JSONObject =
        withContext(Dispatchers.IO) { requestBlocking("POST", path, body, bearer) }

    private fun requestBlocking(
        method: String,
        path: String,
        body: JSONObject?,
        bearer: String?
    ): JSONObject {
        val url = URL(ApiConfig.BASE_URL.trimEnd('/') + "/" + path.trimStart('/'))
        val connection = (url.openConnection() as HttpURLConnection).apply {
            requestMethod = method
            connectTimeout = 12_000
            readTimeout = 20_000
            setRequestProperty("Accept", "application/json")
            setRequestProperty("Content-Type", "application/json; charset=UTF-8")
            if (!bearer.isNullOrBlank()) setRequestProperty("Authorization", "Bearer $bearer")
            doInput = true
            if (body != null) {
                doOutput = true
                outputStream.use { output -> output.write(body.toString().toByteArray(StandardCharsets.UTF_8)) }
            }
        }

        val status = connection.responseCode
        val stream = if (status in 200..299) connection.inputStream else connection.errorStream
        val responseText = stream?.use { input ->
            BufferedReader(InputStreamReader(input, StandardCharsets.UTF_8)).readText()
        }.orEmpty()
        connection.disconnect()

        val responseJson = if (responseText.isBlank()) JSONObject() else JSONObject(responseText)
        if (status !in 200..299) {
            throw ApiException(status, responseJson.optString("message", "Request failed ($status)"))
        }
        return responseJson
    }

    private fun authResult(json: JSONObject): AuthResult = AuthResult(
        user = AuthUser.fromJson(json.getJSONObject("user")),
        accessToken = json.getString("accessToken"),
        refreshToken = json.getString("refreshToken")
    )
}
