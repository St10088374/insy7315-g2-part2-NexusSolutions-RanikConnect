package com.example.ranikconnectdrivermobileapp.data

import org.json.JSONObject

data class AuthUser(
    val id: String,
    val name: String,
    val email: String,
    val role: String,
    val status: String
) {
    companion object {
        fun fromJson(json: JSONObject): AuthUser = AuthUser(
            id = json.optString("id"),
            name = json.optString("name"),
            email = json.optString("email"),
            role = json.optString("role"),
            status = json.optString("status")
        )
    }
}

data class AuthResult(
    val user: AuthUser,
    val accessToken: String,
    val refreshToken: String
)

data class DriverTrip(
    val id: String,
    val bookingReference: String,
    val origin: String,
    val destination: String,
    val cargo: String,
    val scheduledDate: String,
    val status: String,
    val vehicleRegistration: String,
    val vehicleName: String,
    val currentStatus: String,
    val delayed: Boolean,
    val eta: String?
) {
    companion object {
        fun fromJson(json: JSONObject): DriverTrip {
            val booking = json.optJSONObject("booking")
            val vehicle = json.optJSONObject("vehicle")
            val shipment = json.optJSONObject("shipment")
            return DriverTrip(
                id = json.optString("id"),
                bookingReference = booking?.optString("bookingReference").orEmpty(),
                origin = booking?.optString("origin").orEmpty(),
                destination = booking?.optString("destination").orEmpty(),
                cargo = booking?.optString("cargo").orEmpty(),
                scheduledDate = json.optString("scheduledDate").ifBlank { booking?.optString("scheduledDate").orEmpty() },
                status = json.optString("status"),
                vehicleRegistration = vehicle?.optString("registrationNumber").orEmpty(),
                vehicleName = listOf(vehicle?.optString("make").orEmpty(), vehicle?.optString("model").orEmpty())
                    .filter { it.isNotBlank() }
                    .joinToString(" "),
                currentStatus = shipment?.optString("currentStatus") ?: json.optString("status"),
                delayed = shipment?.optBoolean("delayed", false) ?: false,
                eta = shipment?.optString("eta")?.takeIf { it.isNotBlank() }
            )
        }
    }
}
