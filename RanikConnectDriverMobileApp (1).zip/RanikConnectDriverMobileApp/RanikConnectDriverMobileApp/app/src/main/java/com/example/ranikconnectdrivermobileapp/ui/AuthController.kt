package com.example.ranikconnectdrivermobileapp.ui

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.example.ranikconnectdrivermobileapp.data.ApiClient
import com.example.ranikconnectdrivermobileapp.data.ApiException
import com.example.ranikconnectdrivermobileapp.data.AuthUser
import com.example.ranikconnectdrivermobileapp.data.DriverTrip
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

sealed interface AuthScreen {
    data object Login : AuthScreen
    data object Register : AuthScreen
    data object Dashboard : AuthScreen
}

class AuthController(context: Context) {
    private val api = ApiClient(context)
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)

    var screen by mutableStateOf<AuthScreen>(AuthScreen.Login)
        private set
    var user by mutableStateOf<AuthUser?>(null)
        private set
    var trips by mutableStateOf<List<DriverTrip>>(emptyList())
        private set
    var loading by mutableStateOf(false)
        private set
    var message by mutableStateOf<String?>(null)
        private set

    fun initialize() {
        if (loading || user != null) return
        loading = true
        scope.launch {
            try {
                user = api.restoreSession()
                screen = if (user != null) AuthScreen.Dashboard else AuthScreen.Login
                if (user != null) refreshTripsInternal()
            } catch (error: Exception) {
                user = null
                screen = AuthScreen.Login
                message = readableError(error)
            } finally {
                loading = false
            }
        }
    }

    fun goToRegister() {
        message = null
        screen = AuthScreen.Register
    }

    fun goToLogin() {
        message = null
        screen = AuthScreen.Login
    }

    fun login(email: String, password: String) {
        submit {
            val result = api.login(email.trim(), password)
            user = result.user
            screen = AuthScreen.Dashboard
            refreshTripsInternal()
        }
    }

    fun register(
        name: String,
        email: String,
        password: String
    ) {
        submit {
            val result = api.register(name.trim(), email.trim(), password)
            user = result.user
            screen = AuthScreen.Dashboard
            refreshTripsInternal()
        }
    }

    fun refreshTrips() {
        if (loading || user == null) return
        scope.launch {
            loading = true
            try {
                refreshTripsInternal()
            } catch (error: Exception) {
                message = readableError(error)
            } finally {
                loading = false
            }
        }
    }

    fun logout() {
        scope.launch {
            loading = true
            try {
                api.logout()
            } finally {
                trips = emptyList()
                user = null
                screen = AuthScreen.Login
                loading = false
            }
        }
    }

    fun consumeMessage() {
        message = null
    }

    fun close() = scope.cancel()

    private fun submit(block: suspend () -> Unit) {
        if (loading) return
        loading = true
        message = null
        scope.launch {
            try {
                block()
            } catch (error: Exception) {
                message = readableError(error)
                if (error is ApiException && error.statusCode == 401) {
                    user = null
                    screen = AuthScreen.Login
                }
            } finally {
                loading = false
            }
        }
    }

    private suspend fun refreshTripsInternal() {
        trips = api.driverTrips()
    }

    private fun readableError(error: Throwable): String = when (error) {
        is ApiException -> error.message
        is java.net.ConnectException -> "Could not connect to RanikConnect. Check that the MERN API is running on port 5000."
        is java.net.SocketTimeoutException -> "The RanikConnect server took too long to respond."
        else -> error.message ?: "Something went wrong. Please try again."
    }
}
