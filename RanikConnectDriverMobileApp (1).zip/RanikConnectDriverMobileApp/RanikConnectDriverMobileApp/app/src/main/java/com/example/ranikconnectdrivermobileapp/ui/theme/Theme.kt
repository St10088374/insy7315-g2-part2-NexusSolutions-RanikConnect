package com.example.ranikconnectdrivermobileapp.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable

private val LightColors = lightColorScheme(
    primary = RanikBlue,
    onPrimary = androidx.compose.ui.graphics.Color.White,
    primaryContainer = RanikSky,
    onPrimaryContainer = RanikNavy,
    secondary = RanikNavy,
    background = androidx.compose.ui.graphics.Color(0xFFF8FBFF),
    surface = androidx.compose.ui.graphics.Color.White
)

private val DarkColors = darkColorScheme(
    primary = RanikBlue,
    secondary = androidx.compose.ui.graphics.Color(0xFFB9D2FF),
    primaryContainer = RanikNavy
)

@Composable
fun RanikConnectDriverMobileAppTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = if (darkTheme) DarkColors else LightColors,
        typography = Typography,
        content = content
    )
}
