package com.example.ranikconnectdrivermobileapp.ui.theme

import androidx.compose.ui.graphics.Color

val RanikBlue = Color(0xFF135DCE)
val RanikNavy = Color(0xFF0A2342)
val RanikSky = Color(0xFFEAF2FF)
val RanikSuccess = Color(0xFF177245)
